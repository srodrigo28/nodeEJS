export class User {
  username: string;
  roles: string[];
  nome: string;
  sobrenome: string;
  enabled: boolean;
}
