import { EntityInfo } from './entity-info';

describe('EntityInfo', () => {
  it('should create an instance', () => {
    expect(new EntityInfo()).toBeTruthy();
  });
});
