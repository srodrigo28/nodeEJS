export class EntityInfoAccess {
  create: boolean;
  read: boolean;
  update: boolean;
  delete: boolean;
}
