import { EntityInfoAccess } from './entity-info-access';

describe('EntityInfoAccess', () => {
  it('should create an instance', () => {
    expect(new EntityInfoAccess()).toBeTruthy();
  });
});
