import { EntityInfoFk } from './entity-info-fk';

describe('EntityInfoFk', () => {
  it('should create an instance', () => {
    expect(new EntityInfoFk()).toBeTruthy();
  });
});
