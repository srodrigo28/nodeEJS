export class EntityInfoFk {
  entity: string;
  search: string;
  param: string;
}
