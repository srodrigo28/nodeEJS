import { EntityInfoField } from './entity-info-field';

describe('EntityInfoField', () => {
  it('should create an instance', () => {
    expect(new EntityInfoField()).toBeTruthy();
  });
});
