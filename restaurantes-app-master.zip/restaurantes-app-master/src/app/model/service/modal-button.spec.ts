import { ModalButton } from './modal-button';

describe('ModalButton', () => {
  it('should create an instance', () => {
    expect(new ModalButton()).toBeTruthy();
  });
});
