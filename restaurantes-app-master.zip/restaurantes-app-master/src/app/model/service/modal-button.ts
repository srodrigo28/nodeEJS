export class ModalButton {
  name: string;
  callback: Function;
}
