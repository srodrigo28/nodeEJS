export class CrudRequest {
  entity: string;
  id: string;
  special: string;
  param: any[];
  data: object;
}
