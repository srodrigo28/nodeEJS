import { ModalStructure } from './modal-structure';

describe('ModalStructure', () => {
  it('should create an instance', () => {
    expect(new ModalStructure()).toBeTruthy();
  });
});
