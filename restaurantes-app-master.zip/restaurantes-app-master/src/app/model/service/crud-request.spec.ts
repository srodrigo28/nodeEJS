import { CrudRequest } from './crud-request';

describe('CrudRequest', () => {
  it('should create an instance', () => {
    expect(new CrudRequest()).toBeTruthy();
  });
});
